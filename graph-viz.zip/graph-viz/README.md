# Setup

Connect this repository to Heroku and launch on main/master.